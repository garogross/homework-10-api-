import { Route, Switch, Redirect } from 'react-router-dom';

import Player from "./Components/Player/Player"
import Playlist from "./pages/Playlist/Playlist";
import LikedSongs from './pages/LikedSongs/LikedSongs';
import Navigator from './Components/Navigator/Navigator';
import classes from "./App.module.css"

function App() {

  return (
    <div className={classes.app}>
      <div className={classes.container}>
        <Navigator/>
        <Switch>
          <Route path="/" exact>
            <Redirect to="/playlist" />
          </Route>
          <Route path="/playlist" exact>
            <Playlist />
          </Route>
          <Route path="/liked-songs" exact>
            <LikedSongs />
          </Route>
        </Switch>
        <Player />
      </div>
    </div>
  );
}

export default App;
