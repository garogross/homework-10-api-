import { SKIP_SONG, SONG_ENDED, IS_PLAYING, CHOOSE_SONG, LIKE_SONG, DELETE_SONG } from "../constants/index"

const initialState = {
 songs: [
  {
   tittle: "Many Men",
   artist: "50 Cent",
   src: "../../audio/track1.mp3",
   id: 0,
   key: "k1"
  },
  {
   tittle: "Knockdown",
   artist: "Basta",
   src: "../../audio/track2.mp3",
   id: 1,
   key: "k2"
  },
  {
   tittle: "Ritmo",
   artist: "Black Eyed Peas ft. J Balvin",
   src: "../../audio/track3.mp3",
   id: 2,
   key: "k3"
  },
  {
   tittle: "Hate Bein Sober",
   artist: "50 Cent, Chief Keef, Wiz Khalifa",
   src: "../../audio/track4.mp3",
   id: 3,
   key: "k4"
  },
  {
   tittle: "Yes",
   artist: "Fat Joe, Cardi B, Anuel AA, Dre",
   src: "../../audio/track5.mp3",
   id: 4,
   key: "k5"
  },
  {
   tittle: "Mallboro",
   artist: "Grant(Staff)",
   src: "../../audio/track6.mp3",
   id: 5,
   key: "k6"
  },
  {
   tittle: "Khalifas Afair",
   artist: "Hambik A'shot",
   src: "../../audio/track7.mp3",
   id: 6,
   key: "k7"
  },
  {
   tittle: "Warriors",
   artist: "Imagine Dragons",
   src: "../../audio/track8.mp3",
   id: 7,
   key: "k8"
  },
  {
   tittle: "Oh My God",
   artist: "Inna",
   src: "../../audio/track9.mp3",
   id: 8,
   key: "k9"
  },
  {
   tittle: "Barz",
   artist: "Latifah",
   src: "../../audio/track10.mp3",
   id: 9,
   key: "k10"
  },
 ],
 currentSongIndex: 0,
 isPlaying: false,
 likedSongs: []

}


export const playerReducer = (state = initialState, action) => {
  const {
    type,
    temp,
    id,
    song,
    filteredSongs,
    updatedLikedSongs
  } = action
 switch (type) {
  case SKIP_SONG:
   return {
    ...state,
    currentSongIndex: temp
     }
   case SONG_ENDED:
     return {
       ...state,
       currentSongIndex: state.currentSongIndex + 1
     }
   case IS_PLAYING:
     return {
       ...state,
       isPlaying: !state.isPlaying
     }
   case CHOOSE_SONG:
     return {
       ...state,
       isPlaying: true,
       currentSongIndex: id
     }
   case LIKE_SONG:
     return {
       ...state,
       likedSongs: updatedLikedSongs
     }
   case DELETE_SONG:
     return {
       ...state,
       likedSongs: filteredSongs
     }
   default :
   return state 
 }
 
}