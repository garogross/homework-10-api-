export const SKIP_SONG = "SKIP_SONG"
export const SONG_ENDED = "SONG_ENDED"
export const CHOOSE_SONG = "CHOOSE_SONG"
export const IS_PLAYING = "IS_PLAYING"
export const LIKE_SONG = "LIKE_SONG"
export const DELETE_SONG = "DELETE_SONG"





