import React, { useEffect, useState, useCallback } from 'react'
import classes from "./LikedSongs.module.css"
import { useSelector } from 'react-redux'
import PlayItem from '../Playlist/PlayItem/PlayItem'


const LikedSongs = () => {
 const { likedSongs } = useSelector(state => state.player)




 return (
  <div className={classes.likedSongs}>
   {likedSongs.map((song, index) => (
    <PlayItem
     id={song.id}
     index={index}
     artist={song.artist}
     tittle={song.tittle}
     key={song.key}
     song={song}
    />
   ))}
  </div>
 )
}

export default LikedSongs
