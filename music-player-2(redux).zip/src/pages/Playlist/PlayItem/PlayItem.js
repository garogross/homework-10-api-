import React, { useState, useEffect } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faThumbsUp } from '@fortawesome/free-solid-svg-icons'
import { chooseSong, deleteSong, likeSong } from '../../../actions/playerActions'
import { useDispatch, useSelector } from 'react-redux'

import Button from '../../../Components/Button/Button'
import classes from "./PlayItem.module.css"

const PlayItem = (props) => {
  const dispatch = useDispatch()
  const { currentSongIndex, likedSongs } = useSelector(state => state.player)

  const [btnIsActive, setBtnIsActive] = useState(false)





  const chooseSongHandler = (e) => {
    dispatch(chooseSong(e, props.id))
  }
  const likeHandler = (e) => {
    if (!btnIsActive) {
      dispatch(likeSong(props.song))
    } else {
      dispatch(deleteSong(props.id))
    }
    setBtnIsActive(!btnIsActive)


  }
  return (
    <div
      className={`${classes["play-item"]} ${currentSongIndex === props.index ? classes.active : ""}`}
      onClick={chooseSongHandler}>
      <main >
        <img src="https://www.freepnglogos.com/uploads/compact-disc-png-logo/compact-cd-dvd-disk-company-png-logo-35.png" alt="Disk" />
        <p >
          <span><b>{props.tittle}</b></span>
          <span>{props.artist}</span>
        </p>
      </main>
      <Button
        onClick={likeHandler}
        btnIsActive={btnIsActive}
      >
        <FontAwesomeIcon icon={faThumbsUp} />
      </Button>
    </div>
  )
}

export default PlayItem
