import React from 'react'
import classes from "./Playlist.module.css"
import { useSelector } from 'react-redux'
import PlayItem from './PlayItem/PlayItem'

const Playlist = () => {
 const {songs} = useSelector(state => state.player)
 return (
  <div className={classes.playlist}>
   {songs.map((song,index) => (
    <PlayItem
     id={song.id}
     index={index}
     artist={song.artist}
     tittle={song.tittle}
     key={song.key}
     song={song}
    />
   ))}
  </div>
 )
}

export default Playlist
