import {
  SKIP_SONG,
  SONG_ENDED,
  CHOOSE_SONG,
  IS_PLAYING,
  LIKE_SONG,
  DELETE_SONG
} from "../constants/index"


export const skipSong = (forwards = true) => (dispatch, getState) => {
  const { currentSongIndex, songs } = getState().player
  let temp = currentSongIndex
  if (forwards) {
    temp++
    if (temp > songs.length - 1) {
      temp = 0
    }
  } else {
    temp--
    if (temp < 0) {
      temp = songs.length - 1
    }
  }
  dispatch({
    type: SKIP_SONG,
    temp,
  })
}

export const autoSkip = () => (dispatch) => {
  dispatch({
    type: SONG_ENDED,
  })
}

export const isPlayingChange = () => dispatch => {
  dispatch({
    type: IS_PLAYING
  })
}

export const chooseSong = (event, id) => dispatch => {
  if (event.target.tagName === "path" ||
    event.target.tagName === "BUTTON" ||
    event.target.tagName === "svg") {
    return;
  } else {
    dispatch({
      type: CHOOSE_SONG,
      id,
    })

  }

}

export const likeSong = song => (dispatch, getState) => {
  const { likedSongs } = getState().player
  const updatedLikedSongs = [song,...likedSongs]

  dispatch({
    type: LIKE_SONG,
    updatedLikedSongs,
  })

}

export const deleteSong = id => (dispatch, getState) => {
  const {likedSongs} = getState().player
  const filteredSongs = likedSongs.filter(song => song.id !== id)
  dispatch({
    type: DELETE_SONG,
    filteredSongs,
  })


}