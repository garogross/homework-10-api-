import React,{useState} from "react"
import './App.css';
import Form from "./Components/Form/Form"
import ImgList from "./Components/ImgList/ImgList"



function App() {
  const [imgData,setImgData] = useState([])

  const key = "1J1nly0zBrrMc2SvD0h47avXm7yYS9QhBo7eTWej7jE"
  const fetchHandler = (value) => {
    fetch(`https://api.unsplash.com/search/collections?page=1&query=${value}&client_id=${key}`)
    .then(response => response.json())
      .then(data => {
        const myData = data.results.map(item => {
          return {
            id: item.cover_photo.id,
            url: item.cover_photo.urls.regular,
            alt: item.cover_photo.alt_description
          }
        })
        setImgData(myData)
      })
    }
  return (
  
    <div className="App" >
      <Form
        fetchHandler={fetchHandler}
      />
      <ImgList imgData={imgData}/>
    </div>
  );
}

export default App;
